<?php
/**
 * Template for social sharing icons
 * More about Facebook Share dialog: https://developers.facebook.com/docs/sharing/reference/share-dialog
 *
 * @package Digiday Media Network Plugin
 */

if ( ! is_single() ) {
	return;
}

$post_link    = get_the_permalink();
$post_title   = get_the_title();
$fb_app_id    = false;
$utm_medium   = 'social';
$utm_params   = '?utm_medium=' . $utm_medium;

$facebook_link = "https://www.facebook.com/dialog/share?app_id=" . rawurlencode( $fb_app_id ) . "&display=popup&href=" . rawurlencode( $post_link . $utm_params ) . "&utm_source=facebook&redirect_uri=";
$twitter_link  = "https://twitter.com/intent/tweet?url=" . rawurlencode( $post_link . $utm_params . '&utm_source=twitter' ) . ">&text=" . rawurlencode( $post_title );
$linkedin_link = "https://www.linkedin.com/shareArticle?mini=true&url=" . rawurlencode( $post_link . $utm_params . '&utm_source=linkedin' ) ."&title=" . rawurlencode( $post_title );
?>
<div id="social-share-icons" class="">
	<ul>
        <li>
            <a target="popup" title="Share on LinkedIn" onclick="window.open('<?php echo esc_url( $linkedin_link ); ?>','popup','width=600,height=600'); return false;" href="<?php echo esc_url( $linkedin_link ); ?>">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M5 1.25C3.48122 1.25 2.25 2.48122 2.25 4C2.25 5.51878 3.48122 6.75 5 6.75C6.51878 6.75 7.75 5.51878 7.75 4C7.75 2.48122 6.51878 1.25 5 1.25ZM3.75 4C3.75 3.30964 4.30964 2.75 5 2.75C5.69036 2.75 6.25 3.30964 6.25 4C6.25 4.69036 5.69036 5.25 5 5.25C4.30964 5.25 3.75 4.69036 3.75 4Z" fill="currentColor"></path>
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M2.25 8C2.25 7.58579 2.58579 7.25 3 7.25H7C7.41421 7.25 7.75 7.58579 7.75 8V21C7.75 21.4142 7.41421 21.75 7 21.75H3C2.58579 21.75 2.25 21.4142 2.25 21V8ZM3.75 8.75V20.25H6.25V8.75H3.75Z" fill="currentColor"></path>
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M9.25 8C9.25 7.58579 9.58579 7.25 10 7.25H14C14.4142 7.25 14.75 7.58579 14.75 8V8.43402L15.1853 8.24748C15.9336 7.92676 16.7339 7.72565 17.5433 7.65207C20.3182 7.3998 22.75 9.58038 22.75 12.3802V21C22.75 21.4142 22.4142 21.75 22 21.75H18C17.5858 21.75 17.25 21.4142 17.25 21V14C17.25 13.6685 17.1183 13.3505 16.8839 13.1161C16.6495 12.8817 16.3315 12.75 16 12.75C15.6685 12.75 15.3505 12.8817 15.1161 13.1161C14.8817 13.3505 14.75 13.6685 14.75 14V21C14.75 21.4142 14.4142 21.75 14 21.75H10C9.58579 21.75 9.25 21.4142 9.25 21V8ZM10.75 8.75V20.25H13.25V14C13.25 13.2707 13.5397 12.5712 14.0555 12.0555C14.5712 11.5397 15.2707 11.25 16 11.25C16.7293 11.25 17.4288 11.5397 17.9445 12.0555C18.4603 12.5712 18.75 13.2707 18.75 14V20.25H21.25V12.3802C21.25 10.4759 19.589 8.97227 17.6791 9.14591C17.025 9.20536 16.3784 9.36807 15.7762 9.6262L14.2954 10.2608C14.0637 10.3601 13.7976 10.3363 13.5871 10.1976C13.3767 10.0588 13.25 9.82354 13.25 9.57143V8.75H10.75Z" fill="currentColor"></path>
                </svg>
            </a>
        </li>
        <li>
            <a target="popup" title="Share on X" onclick="window.open('<?php echo esc_url( $twitter_link ); ?>','popup','width=600,height=600'); return false;" href="<?php echo esc_url( $twitter_link ); ?>">
                <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M11.9027 8.89207L19.3482 0H17.5838L11.1189 7.72086L5.95547 0H0L7.8082 11.6753L0 21H1.76443L8.59152 12.8465L14.0445 21H20L11.9027 8.89207ZM9.48608 11.7782L8.69495 10.6156L2.40018 1.36466H5.11025L10.1902 8.83044L10.9813 9.99304L17.5847 19.6974H14.8746L9.48608 11.7782Z" fill="currentColor"></path>
                </svg>
            </a>
        </li>
		<?php if ( false !== $fb_app_id ) { ?>
		<li>
            <a target="popup" title="Share on Facebook" onclick="window.open('<?php echo esc_url( $facebook_link ); ?>','popup','width=600,height=600'); return false;" href="<?php echo esc_url( $facebook_link ); ?>">
                <span class="dashicons dashicons-facebook">Facebook</span>
            </a>
        </li>
		<?php } ?>
        <li>
            <a class="social-share-link" href="#">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_4475_3028)">
                        <path d="M8 12H16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M9 8H6C3.79086 8 2 9.79086 2 12C2 14.2091 3.79086 16 6 16H9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M15 8H18C20.2091 8 22 9.79086 22 12C22 14.2091 20.2091 16 18 16H15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                    </g>
                    <defs>
                        <clipPath id="clip0_4475_3028">
                            <rect width="24" height="24" fill="white"></rect>
                        </clipPath>
                    </defs>
                </svg>
            </a>
        </li>
	</ul>
</div>




<ul class="icons">
    <li><a href="#"></a></li>

</ul>



