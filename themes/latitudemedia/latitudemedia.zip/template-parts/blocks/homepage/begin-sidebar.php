<?php
if (is_admin()) {
    echo '<h3 style="text-align: center;">BEGIN SIDEBAR</h3>';
}

if (!is_admin()) :

?>

<div class="right-sidebar-layout">
    <div class="container">
        <div class="right-sidebar-layout-wrapper">
            <div class="main-column">

<?php endif; ?>
