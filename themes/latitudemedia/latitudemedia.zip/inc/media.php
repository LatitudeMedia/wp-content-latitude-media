<?php

add_image_size( 'home-top', 1300, 1424, true );
